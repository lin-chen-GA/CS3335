var indexSectionsWithContent =
{
  0: "dhmpsu",
  1: "hmu",
  2: "dh",
  3: "ps"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Pages"
};

